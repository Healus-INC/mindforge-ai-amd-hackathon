"""Evaluate LoRA outputs on demo/eval cases for JSON validity and simple risk labels."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--cases", default="data/synthetic/mindforge_eval_cases.json")
    p.add_argument("--base_model", default="Qwen/Qwen2.5-0.5B-Instruct")
    p.add_argument("--adapter_dir", default="outputs/mindforge-qwen-lora")
    p.add_argument("--limit", type=int, default=5)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    cases_obj = json.loads(Path(args.cases).read_text())
    if isinstance(cases_obj, dict):
        cases = cases_obj.get("cases", cases_obj.get("items", []))
    else:
        cases = cases_obj
    out_dir = Path("outputs/eval_cases")
    out_dir.mkdir(parents=True, exist_ok=True)
    valid = 0
    total = 0
    for idx, case in enumerate(cases[: args.limit], start=1):
        case_path = out_dir / f"case_{idx}.json"
        case_path.write_text(json.dumps(case, indent=2), encoding="utf-8")
        cmd = [
            sys.executable,
            "training/infer_lora.py",
            "--base_model", args.base_model,
            "--adapter_dir", args.adapter_dir,
            "--case_json", str(case_path),
        ]
        proc = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        result = proc.stdout
        total += 1
        is_valid = "JSON_VALID=true" in result
        valid += int(is_valid)
        print("=" * 80)
        print("CASE", idx, "VALID", is_valid)
        print(result[:2500])
    print("=" * 80)
    print(json.dumps({"total": total, "json_valid": valid, "json_valid_rate": valid / max(total, 1)}, indent=2))


if __name__ == "__main__":
    main()
