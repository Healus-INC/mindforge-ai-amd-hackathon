"""Minimal Gradio demo using the trained LoRA adapter.
Run on GPU droplet or Hugging Face Space.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import gradio as gr
import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

BASE_MODEL = os.getenv("BASE_MODEL", "Qwen/Qwen2.5-0.5B-Instruct")
ADAPTER_DIR = os.getenv("ADAPTER_DIR", "outputs/mindforge-qwen-lora")
DEMO_CASES_PATH = os.getenv("DEMO_CASES_PATH", "data/synthetic/mindforge_demo_cases.json")

SYSTEM = """You are MindForge AI, a mental-health risk review assistant for a synthetic hackathon demo.
Return ONLY valid JSON. Do not diagnose, prescribe, or replace a clinician. Use conservative safety escalation.
Synthetic demo data only; no PHI."""


def load_cases():
    path = Path(DEMO_CASES_PATH)
    if not path.exists():
        return {"Custom case": {"patient_note": "Patient missed two doses and slept 3 hours.", "device_or_app_events": {}}}
    obj = json.loads(path.read_text())
    cases = obj.get("cases", obj) if isinstance(obj, dict) else obj
    result = {}
    for c in cases:
        label = c.get("title") or c.get("case_id") or f"Case {len(result)+1}"
        result[label] = c
    return result

CASES = load_cases()

print("Loading model", BASE_MODEL, ADAPTER_DIR)
tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL, trust_remote_code=True, use_fast=True)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
base = AutoModelForCausalLM.from_pretrained(
    BASE_MODEL,
    torch_dtype=torch.bfloat16 if torch.cuda.is_available() else torch.float32,
    device_map="auto" if torch.cuda.is_available() else None,
    trust_remote_code=True,
)
try:
    model = PeftModel.from_pretrained(base, ADAPTER_DIR)
except Exception as e:
    print("Adapter load failed, using base model only:", e)
    model = base
model.eval()


def extract_json(text: str):
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return text, None
    candidate = text[start:end+1]
    try:
        return candidate, json.loads(candidate)
    except Exception:
        return candidate, None


def run(case_label, free_text):
    case = CASES.get(case_label, {})
    if free_text and free_text.strip():
        case = {
            "case_id": "CUSTOM-DEMO",
            "context_type": "synthetic_demo",
            "patient_note": free_text.strip(),
            "device_or_app_events": {
                "doses_scheduled": 14,
                "doses_taken": 12,
                "missed_doses_7d": 2,
                "sleep_hours_last_night": 4,
                "mood_score_1_to_10": 3,
            },
            "task": "Return a structured mental-health risk review JSON for the care loop.",
        }
    messages = [
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content": json.dumps(case)},
    ]
    prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        out = model.generate(
            **inputs,
            max_new_tokens=700,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
        )
    raw = tokenizer.decode(out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
    candidate, parsed = extract_json(raw)
    if parsed:
        risk = parsed.get("risk_level", "UNKNOWN")
        score = parsed.get("risk_score", "")
        patient = parsed.get("patient_safe_response", "")
        clinician = parsed.get("clinician_summary", "")
        esc = parsed.get("escalation_recommendation", {})
        return risk, str(score), json.dumps(esc, indent=2), patient, clinician, json.dumps(parsed, indent=2)
    return "PARSE_ERROR", "", "", "", "", candidate

with gr.Blocks(title="MindForge AI") as demo:
    gr.Markdown("# MindForge AI\nMental health risk review copilot for synthetic hackathon demo cases. Not medical advice. No real patient data.")
    with gr.Row():
        case_label = gr.Dropdown(list(CASES.keys()), value=list(CASES.keys())[0], label="Demo case")
        free_text = gr.Textbox(label="Optional custom synthetic note", lines=5)
    btn = gr.Button("Run risk review")
    with gr.Row():
        risk = gr.Textbox(label="Risk Level")
        score = gr.Textbox(label="Risk Score")
    escalation = gr.Code(label="Escalation Recommendation", language="json")
    patient = gr.Textbox(label="Patient-safe response", lines=3)
    clinician = gr.Textbox(label="Clinician summary", lines=3)
    raw_json = gr.Code(label="Structured JSON", language="json")
    btn.click(run, inputs=[case_label, free_text], outputs=[risk, score, escalation, patient, clinician, raw_json])

if __name__ == "__main__":
    demo.launch(server_name="0.0.0.0", server_port=int(os.getenv("PORT", "7860")))
