# MindForge Fine-Tuning Step 2 Package

Copy these files into the root of the GitHub repo:

```bash
unzip mindforge_finetune_step2.zip -d mindforge-ai-amd-hackathon
```

Main command:

```bash
python training/train_qwen_lora_trl.py \
  --base_model Qwen/Qwen2.5-0.5B-Instruct \
  --train_file data/synthetic/mindforge_train.jsonl \
  --validation_file data/synthetic/mindforge_validation.jsonl \
  --output_dir outputs/mindforge-qwen-lora \
  --epochs 6
```
