# Quick Start: 100x Dataset

Validate:

```bash
python scripts/validate_sft_jsonl_100x.py \
  data/synthetic/mindforge_train_100x.jsonl \
  data/synthetic/mindforge_validation_100x.jsonl

python scripts/dataset_stats_100x.py \
  data/synthetic/mindforge_train_100x.jsonl
```

Recommended first 100x fine-tune:

```bash
python training/train_qwen_lora_trl.py \
  --base_model Qwen/Qwen2.5-0.5B-Instruct \
  --train_file data/synthetic/mindforge_train_100x.jsonl \
  --validation_file data/synthetic/mindforge_validation_100x.jsonl \
  --output_dir outputs/mindforge-qwen-lora-100x \
  --epochs 1 \
  --batch_size 1 \
  --grad_accum 16 \
  --learning_rate 1.5e-4
```

For hackathon speed, 1 epoch is enough to prove the pipeline if the 10x dataset already works.
