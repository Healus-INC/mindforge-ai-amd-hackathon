# Data Card: MindForge AI 100x Synthetic Dataset

## Dataset type
Synthetic instruction-following SFT data for a mental-health risk review copilot demo.

## Primary task
Given synthetic patient/caregiver/device context, return structured JSON with:
- risk level
- risk score
- key flags
- medication adherence status
- escalation recommendation
- patient-safe response
- clinician summary
- care-loop actions
- safety disclaimer

## Risk labels
LOW, MODERATE, HIGH, CRISIS.

## Not for
- clinical diagnosis
- medication decision-making
- emergency triage in production
- training on real patient records
- any HIPAA/PHI use case without proper governance

## Known limitations
The examples are synthetic and template-derived. They are useful for teaching output format, role behavior, safety phrasing, and demo consistency. They are not clinical ground truth.
