#!/usr/bin/env python3
import json, sys, collections
from pathlib import Path

for p in sys.argv[1:]:
    counts = collections.Counter()
    meds = collections.Counter()
    conditions = collections.Counter()
    n = 0
    for line in Path(p).read_text(encoding="utf-8").splitlines():
        if not line.strip(): continue
        n += 1
        r = json.loads(line)
        counts[r["target_risk_level"]] += 1
        meds[r["metadata"]["medication"]] += 1
        conditions[r["metadata"]["condition_category"]] += 1
    print("\n", p)
    print("rows:", n)
    print("risk:", dict(counts))
    print("top meds:", meds.most_common(10))
    print("top conditions:", conditions.most_common(10))
