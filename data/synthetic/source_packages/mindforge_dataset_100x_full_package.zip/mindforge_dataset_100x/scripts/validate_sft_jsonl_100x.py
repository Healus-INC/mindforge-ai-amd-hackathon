#!/usr/bin/env python3
import json, sys
from pathlib import Path

def validate_file(path):
    n = 0
    bad = 0
    for line_no, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        n += 1
        try:
            row = json.loads(line)
            assert row.get("synthetic") is True
            assert row["messages"][0]["role"] == "system"
            assert row["messages"][1]["role"] == "user"
            assert row["messages"][2]["role"] == "assistant"
            out = json.loads(row["messages"][2]["content"])
            assert out["risk_level"] in ["LOW","MODERATE","HIGH","CRISIS"]
            assert isinstance(out["risk_score"], int)
            for key in ["summary","key_flags","medication_adherence","escalation","patient_safe_response","clinician_summary","care_loop_actions","safety_disclaimer"]:
                assert key in out
        except Exception as e:
            bad += 1
            print(f"BAD {path}:{line_no}: {e}")
    print(f"{path}: rows={n}, bad={bad}")
    return bad

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: validate_sft_jsonl_100x.py FILE.jsonl [FILE2.jsonl ...]")
        sys.exit(2)
    total_bad = sum(validate_file(p) for p in sys.argv[1:])
    sys.exit(1 if total_bad else 0)
