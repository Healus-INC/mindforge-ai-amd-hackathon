# MindForge AI 100x Synthetic Fine-Tuning Dataset

Generated: 2026-05-10T05:11:20.264571+00:00

This package expands the MindForge synthetic dataset to a larger hackathon-scale SFT/LoRA corpus.

## Contents

- `data/synthetic/mindforge_train_100x.jsonl` — 7,200 synthetic training examples
- `data/synthetic/mindforge_validation_100x.jsonl` — 800 validation examples
- `data/synthetic/mindforge_eval_cases_100x.json` — 400 held-out eval-style cases
- `data/synthetic/demo/mindforge_demo_cases_100x.json` — 32 demo cases
- `data/synthetic/mindforge_output_schema_100x.json`
- `data/synthetic/mindforge_risk_rubric_100x.json`
- `data/synthetic/mindforge_safety_policy_100x.json`
- `scripts/validate_sft_jsonl_100x.py`
- `scripts/dataset_stats_100x.py`
- `training/mindforge_100x_training_config.json`
- `docs/DATA_CARD_100x.md`
- `docs/QUICKSTART_100x.md`

## Practical recommendation

For the hackathon:
1. Train first on the 10x dataset.
2. Use this 100x dataset only if the training pipeline is stable.
3. Do not jump to 1,000x or 10,000x synthetic data for the hackathon unless you also add quality filtering, deduplication, and better evaluation.

## Safety

Synthetic data only. No PHI. Not medical advice. Not for production clinical decision-making.
